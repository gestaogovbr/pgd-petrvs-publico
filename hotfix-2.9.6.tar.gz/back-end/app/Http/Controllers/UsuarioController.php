<?php

namespace App\Http\Controllers;

use App\Exceptions\Contracts\IBaseException;
use App\Services\CalendarioService;
use Illuminate\Http\Request;
use App\Http\Controllers\ControllerBase;
use App\Exceptions\ServerException;
use App\Services\NivelAcessoService;
use Illuminate\Support\Facades\Log;
use Throwable;
use ZipArchive;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Response;

class UsuarioController extends ControllerBase
{
    public static $sameTransaction = true;

    public $updatable = ["config", "notificacoes", "texto_complementar_plano", "perfil_id"];

    public function checkPermissions($action, $request, $service, $unidade, $usuario)
    {
        switch ($action) {
            case 'STORE':
                if (!$usuario->hasPermissionTo('MOD_USER_EDT'))
                    throw new ServerException("CapacidadeStore", "Inserção não realizada");
                break;
            case 'EDIT':
                if (!$usuario->hasPermissionTo('MOD_USER_EDT'))
                    throw new ServerException("CapacidadeStore", "Edição não realizada");
                break;
            case 'DESTROY':
                if (!$usuario->hasPermissionTo('MOD_USER_EXCL')) {
                    throw new ServerException("UsuarioDestroy", "Exclusão não realizada");
                }

                $nivelAcessoService = new NivelAcessoService();
                $dados = $this->service->getById(['id' => $request->input('id')]);

                if ($dados->perfil->id != $nivelAcessoService->getPerfilColaborador()->id) {
                    throw new ServerException("UsuarioDestroyNaoColaborador");
                }

                break;
        }
    }

    public function calculaDataTempoUnidade(Request $request)
    {
        try {
            $data = $request->validate([
                'inicio' => ['required'],
                'fimOuTempo' => ['required'],
                'cargaHoraria' => ['required'],
                'unidade_id' => ['required'],
                'tipo' => ['required'],
                'pausas' => [],
                'afastamentos' => []
            ]);
            return response()->json([
                'success' => true,
                'data' => CalendarioService::preparaParametros($data)
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);
        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }

    public function consultarCPFSiape(Request $request)
    {
        $request->validate([
            'cpf' => [],
        ]);

        try {
            $retorno = $this->service->consultaCPFSiape($request->cpf);

            return response()->json([
                'success' => true,
                'funcionais' => $retorno['funcionais'],
                'pessoais' => $retorno['pessoais']
            ]);
        } catch (Throwable $e) {
            report($e);
            return response()->json([
                'success' => false,
                'message' => $e->getMessage()
            ], Response::HTTP_BAD_REQUEST);
        }
    }

    public function exportarCPFSiape(Request $request)
    {
        $data = $request->validate([
            'cpf' => [],
        ]);

        $nomeArquivo = 'dados_cpf_' . $data['cpf'] . '.zip';

        try {
            $retornos = $this->service->consultaCpfSiapeXml($request->cpf);

            $zipFile = tempnam(sys_get_temp_dir(), 'zip');
            $zip = new ZipArchive();
            $zip->open($zipFile, ZipArchive::CREATE | ZipArchive::OVERWRITE);

            foreach ($retornos as $index => $retorno) {
                $tempFile = tempnam(sys_get_temp_dir(), 'xml');
                $xmlContent = $this->normalizaParaXmlString($retorno);
                file_put_contents($tempFile, $xmlContent);
                $zip->addFile($tempFile, "arquivo_{$index}.xml");
            }

            $zip->close();

            return response()->download($zipFile, $nomeArquivo, [
                'Content-Type' => 'application/zip',
                'Content-Disposition' => sprintf('attachment; filename="%s"', $nomeArquivo),
            ])->deleteFileAfterSend(true);

        } catch (\Throwable $th) {
            report($th);

            $tempFile = tempnam(sys_get_temp_dir(), 'txt');
            $mensagemErro = date('Y-m-d H:i:s') . " - " . $th->getMessage() . PHP_EOL;

            file_put_contents($tempFile, $mensagemErro, FILE_APPEND);

            return response()->download($tempFile, $nomeArquivo)->deleteFileAfterSend(true);
        }
    }

    private function normalizaParaXmlString($data): string
    {
        try {
            if ($data instanceof \SimpleXMLElement) {
                return $data->asXML();
            }

            if (is_array($data)) {
                $xml = new \SimpleXMLElement('<out/>');
                $this->arrayParaXml($data, $xml);
                return $xml->asXML();
            }

            if (is_string($data)) {
                return $data;
            }

            return json_encode($data, JSON_UNESCAPED_UNICODE);
        } catch (\Throwable $e) {
            report($e);
            return '<out><error>Falha ao converter dados para XML</error></out>';
        }
    }

    private function arrayParaXml(array $data, \SimpleXMLElement $xml): void
    {
        foreach ($data as $key => $value) {
            $tag = is_numeric($key) ? 'item' : preg_replace('/[^a-zA-Z0-9_\-]/', '', (string) $key);
            if (is_array($value)) {
                $child = $xml->addChild($tag);
                $this->arrayParaXml($value, $child);
            } else {
                $xml->addChild($tag, htmlspecialchars((string) $value));
            }
        }
    }

    public function downloadLogSiape(Request $request)
    {
        $tenantId = function_exists('tenant') ? (tenant('id') ?? 'central') : 'central';
        $logPath = storage_path('logs/siape_' . $tenantId . '.log');

        if (!file_exists($logPath)) {
            return response()->json(['error' => 'Arquivo de log não encontrado.'], 404);
        }

        return response()->download(
            $logPath,
            'siape_' . $tenantId . '.log',
            [
                'Content-Type' => File::mimeType($logPath),
                'Content-Disposition' => 'attachment; filename="siape_' . $tenantId . '.log"',
            ]
        );
    }
    public function atualizaPedagio(Request $request)
    {
        try {
            if (!parent::loggedUser()->hasPermissionTo('MOD_PART_PEDAGIO'))
                throw new ServerException("ValidateUsuario", "Usuário precisa ter capacidade MOD_PART_PEDAGIO");

            $data = $request->input('data');
            $validated = validator($data, [
                'usuario_id' => ['required', 'uuid'],
                'data_inicial_pedagio' => ['required', 'date', 'before_or_equal:data_final_pedagio'],
                'data_final_pedagio' => ['required', 'date', 'after_or_equal:data_inicial_pedagio'],
                'tipo_pedagio' => ['required', 'integer', 'in:1,2'],
            ])->validate();
            return response()->json([
                'success' => true,
                'data' => $this->service->atualizaPedagio($validated)
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);

        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }

    public function removerPedagio(Request $request)
    {
        try {
            if (!parent::loggedUser()->hasPermissionTo('MOD_PART_PEDAGIO'))
                throw new ServerException("ValidateUsuario", "Usuário precisa ter capacidade MOD_PART_PEDAGIO");

            $data = $request->input('data');
            $validated = validator($data, [
                'usuario_id' => ['required', 'uuid'],
            ])->validate();
            return response()->json([
                'success' => true,
                'data' => $this->service->removePedagio($validated)
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);

        }  catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }

    public function matriculas(Request $request)
    {
        try {
            $data = $request->validate([
                'cpf' => ['required', 'string', 'size:11']
            ]);

            $usuarios = $this->service->matriculas($data['cpf']);

            return response()->json([
                'success' => true,
                'usuarios' => $usuarios
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);
        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }

    public function ativarTemporariamente(Request $request)
    {
        try {
            if (!parent::loggedUser()->hasPermissionTo('MOD_USER_EDT'))
                throw new ServerException("ValidateUsuario", "Usuário precisa ter capacidade MOD_USER_EDT");

            $data = $request->input('data');
            $validated = validator($data, [
                'usuario_id' => ['required', 'uuid'],
                'justificativa' => ['required', 'string'],
            ])->validate();
            
            return response()->json([
                'success' => true,
                'data' => $this->service->ativarTemporariamente($validated)
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);
        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }
    
    public function unidadesVinculadas(Request $request)
    {
        try {
            $data = $request->validate([
                'cpf' => ['required', 'string', 'size:11']
            ]);

            $unidades = $this->service->unidadesVinculadas($data['cpf']);

            return response()->json([
                'success' => true,
                'unidades' => $unidades
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);
        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }

    public function pendenciasChefe(Request $request)
    {
        try {
            $pendencias = $this->service->pendenciasChefe();

            return response()->json([
                'success' => true,
                'pendencias' => $pendencias
            ]);
        } catch (IBaseException $e) {
            return response()->json(['error' => $e->getMessage()]);
        } catch (Throwable $e) {
            $dataError = throwableToArrayLog($e);
            Log::error($dataError);
            return response()->json(['error' => "Codigo " . $dataError['code'] . ": Ocorreu um erro inesperado."]);
        }
    }
}
